import { Op, QueryTypes, type Sequelize } from 'sequelize';

import app from '../src/app.js';
import { Job } from '../src/model.js';

const sequelize: Sequelize = app.get('sequelize');

const allJobs = await Job.findAll({
  where: {
    paid: true,
    paymentDate: {
      [Op.between]: ['2023-01-01', '2030-01-02'],
    },
  },
  include: 'Contract',
});

console.log(allJobs.map((job) => job.toJSON()));

const result = await sequelize.query(
  `
  SELECT "Profiles"."id", "Profiles"."firstName" || "Profiles"."lastName" as "fullName", SUM("price") AS "totalPaid"
  FROM "Profiles"
  INNER JOIN "Contracts" ON "Profiles"."id" = "Contracts"."clientId"
  INNER JOIN "Jobs" ON "Contracts"."id" = "Jobs"."contractId"
  WHERE "Profiles"."type" = 'client'
  AND "Jobs"."paid" = true
  AND "Jobs"."paymentDate" BETWEEN '2030-01-01' AND '2030-01-03'
  GROUP BY "Profiles"."id"
  ORDER BY "totalPaid" DESC
  LIMIT 3
`,
  {
    type: QueryTypes.SELECT,
  },
);

console.log(result);
